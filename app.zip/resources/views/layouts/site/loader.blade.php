<div class="page-loader">
    <div></div>
    <div></div>
    <div></div>
</div>
