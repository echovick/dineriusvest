<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
 */

// Home
Route::get('/', function () {
    return view('site.home');
});

// About
Route::get('/about', function () {
    return view('site.about');
});

// Product
Route::get('/products', function () {
    return view('site.products');
});

// Contant
Route::get('/contact', function () {
    return view('site.contact');
});

// Sign In
Route::get('/signin', function () {
    return view('site.signin');
});
