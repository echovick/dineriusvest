<?php

namespace App\Http\Controllers;

use App\Models\UserProduct;
use App\Http\Requests\StoreUserProductRequest;
use App\Http\Requests\UpdateUserProductRequest;

class UserProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreUserProductRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(UserProduct $userProduct)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(UserProduct $userProduct)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUserProductRequest $request, UserProduct $userProduct)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(UserProduct $userProduct)
    {
        //
    }
}
