<?php

use App\Http\Controllers\SiteController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
 */

// Home
Route::group(['prefix' => ''], function () {
    Route::get('/', [SiteController::class, 'home'])->name('site.home');
    Route::get('/about', [SiteController::class, 'about'])->name('site.about');
    Route::get('/products', [SiteController::class, 'products'])->name('site.products');
    Route::get('/guide', [SiteController::class, 'guide'])->name('site.guide');
    Route::get('/education', [SiteController::class, 'education'])->name('site.education');
    Route::get('/contact', [SiteController::class, 'contact'])->name('site.contact');
    Route::get('/signin', [SiteController::class, 'signin'])->name('site.signin');
});
