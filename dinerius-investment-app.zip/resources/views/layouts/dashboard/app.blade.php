@include('layouts.dashboard.header')
@yield('content')
@include('layouts.dashboard.footer')
