    <!-- page loader begin -->
    <?php echo $__env->make('layouts.site.loader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- page loader end -->

    <!-- header begin -->
    <?php if(url()->current() === url('/')): ?>
        <?php echo $__env->make('layouts.site.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('layouts.site.header-two', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <!-- header end -->

    <!-- Content section -->
    <?php echo $__env->yieldContent('content'); ?>

    <!-- footer begin -->
    <?php echo $__env->make('layouts.site.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- footer end -->
<?php /**PATH C:\Users\HP\Documents\dinerius\dinerius-investment-app\resources\views/layouts/site/app.blade.php ENDPATH**/ ?>