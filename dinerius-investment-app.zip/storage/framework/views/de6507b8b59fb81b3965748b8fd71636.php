<div class="page-loader">
    <div></div>
    <div></div>
    <div></div>
</div>
<?php /**PATH C:\Users\HP\Documents\dinerius\dinerius-investment-app\resources\views/layouts/site/loader.blade.php ENDPATH**/ ?>