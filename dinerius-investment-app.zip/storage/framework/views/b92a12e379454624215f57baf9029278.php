<?php $__env->startSection('title', 'DENARIUSVEST - Sign In'); ?>

<?php $__env->startSection('content'); ?>
<main>
    <!-- section content begin -->
    <div class="uk-section uk-padding-remove-vertical">
        <div class="uk-container uk-container-expand">
            <div class="container">
                <div class="uk-width-expand@m uk-flex uk-flex-middle" style="width:50%; margin:auto;">
                    <div class="margin:auto;">
                        <div class="uk-width-3-5@m" style="margin: auto">
                            <div class="uk-text-center in-padding-horizontal@s">
                                <a class="uk-logo" href="<?php echo e(url('/')); ?>">
                                    <img src="img/logo.png" data-src="img/logo.png" alt="logo" width="134" height="23" data-uk-img>
                                </a>
                                <p class="uk-text-lead uk-margin-small-top uk-margin-medium-bottom">Enter your email to reset your password</p>
                                <!-- login form begin -->
                                <form class="uk-grid uk-form">
                                    <div class="uk-margin-small uk-width-1-1 uk-inline">
                                        <span class="uk-form-icon uk-form-icon-flip fas fa-user fa-sm"></span>
                                        <input class="uk-input uk-border-rounded" id="email" value="" type="email" placeholder="Email" required>
                                    </div>
                                    
                                    <div class="uk-margin-small uk-width-expand uk-text-small">
                                        <label class="uk-align-right"><a class="uk-link-reset" href="<?php echo e('/forgot-password'); ?>">Resend OTP</a></label>
                                    </div>
                                    <div class="uk-margin-small uk-width-1-1">
                                        <button class="uk-button uk-width-1-1 uk-button-primary uk-border-rounded uk-float-left" type="submit" name="submit">Sign in</button>
                                    </div>
                                </form>
                                <!-- login form end -->
                                
                                <span class="uk-text-small">I remember my password? <a href="<?php echo e(url('/signup')); ?>">Click here</a></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- section content end -->
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\dinerius\dinerius-investment-app\resources\views/site/forgot-password.blade.php ENDPATH**/ ?>