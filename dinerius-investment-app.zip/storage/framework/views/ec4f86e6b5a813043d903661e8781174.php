<?php $__env->startSection('title', 'Account - Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="nk-content nk-content-lg nk-content-fluid">
        <div class="container-xl wide-lg">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="nk-block-head nk-block-head-lg">
                        <div class="nk-block-head-content">
                            <div class="nk-block-head-sub">
                                <a href="" class="back-to"><em class="icon ni ni-arrow-left"></em><span>Back</span></a>
                            </div>
                            <div class="nk-block-head-content">
                                <h2 class="nk-block-title fw-normal">
                                    <?php echo e($category?->name); ?>

                                </h2>
                            </div>
                        </div>
                    </div>
                    <div class="nk-block invest-block">
                        <form action="#" class="invest-form">
                            <div class="row g-gs">
                                <div class="col-lg-9">
                                    <?php $__currentLoopData = $category->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="invest-field form-group">
                                            <input type="hidden" value="silver" name="iv-plan" id="invest-choose-plan" />
                                            <div class="dropdown invest-cc-dropdown">
                                                <a href="#" class="invest-cc-chosen dropdown-indicator"
                                                    data-bs-toggle="dropdown">
                                                    <div class="coin-item">
                                                        <div class="coin-icon">
                                                            <em class="icon ni ni-offer-fill"></em>
                                                        </div>
                                                        <div class="coin-info">
                                                            <span class="coin-name"><?php echo e($product->name); ?></span>
                                                            
                                                        </div>
                                                    </div>
                                                </a>
                                                <div class="dropdown-menu dropdown-menu-auto dropdown-menu-mxh">
                                                    <li class="invest-cc-item selected">
                                                        <a href="#" class="invest-cc-opt" data-plan="silver">
                                                            <div class="coin-item">
                                                                <div class="coin-info">
                                                                    <span class="coin-text">
                                                                        <?php echo e($product->description); ?></span>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </li>
                                                    <div class="d-flex justify-content-end">
                                                        <a class="btn btn-sm btn-primary m-3"
                                                            href="<?php echo e(route('dashboard.investmentInfo', $product->id)); ?>">Learn
                                                            More</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\dinerius\dinerius-investment-app\resources\views/dashboard/productCategoryInfo.blade.php ENDPATH**/ ?>