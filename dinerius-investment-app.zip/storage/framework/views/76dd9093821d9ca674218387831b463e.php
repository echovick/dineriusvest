<?php $__env->startSection('title', 'Account - Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="nk-content nk-content-lg nk-content-fluid">
        <div class="container-xl wide-lg">
            <div class="nk-content-inner">
                <div class="nk-content-body">
                    <div class="nk-block-head">
                        <div class="nk-block-head-content">
                            <div class="nk-block-head-sub"><span>My Investments</span></div>
                            <div class="nk-block-between-md g-4">
                                <div class="nk-block-head-content">
                                    <h2 class="nk-block-title fw-normal">
                                        Invested Schemes
                                    </h2>
                                    <div class="nk-block-des">
                                        <p>
                                            Here is your current balance and your active
                                            investement plans.
                                        </p>
                                    </div>
                                </div>
                                <div class="nk-block-head-content">
                                    <ul class="nk-block-tools gx-3">
                                        <li>
                                            <a href="#" class="btn btn-primary"><span>Withdraw</span>
                                                <em class="icon ni ni-arrow-long-right d-none d-sm-inline-block"></em></a>
                                        </li>
                                        <li>
                                            <a href="<?php echo e(route('dashboard.investment.new', 1)); ?>"
                                                class="btn btn-white btn-light"><span>Invest More</span>
                                                <em class="icon ni ni-arrow-long-right d-none d-sm-inline-block"></em></a>
                                        </li>
                                        <li class="opt-menu-md dropdown">
                                            <a href="#" class="btn btn-white btn-light btn-icon"
                                                data-bs-toggle="dropdown"><em class="icon ni ni-setting"></em></a>
                                            <div class="dropdown-menu dropdown-menu-end">
                                                <ul class="link-list-opt no-bdr">
                                                    <li>
                                                        <a href="#"><em class="icon ni ni-coin-alt"></em><span>Curreny
                                                                Settings</span></a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><em class="icon ni ni-notify"></em><span>Push
                                                                Notification</span></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="nk-block">
                        <div class="card card-bordered">
                            <div class="card-inner-group">
                                <div class="card-inner">
                                    <div class="row gy-gs">
                                        <div class="col-lg-5">
                                            <div class="nk-iv-wg3">
                                                <div class="nk-iv-wg3-title">Total Balance</div>
                                                <div class="nk-iv-wg3-group flex-lg-nowrap gx-4">
                                                    <div class="nk-iv-wg3-sub">
                                                        <div class="nk-iv-wg3-amount">
                                                            <div class="number">
                                                                <?php echo e(number_format($allUserInvestments->sum('invested_amount'))); ?>

                                                                <small class="currency currency-usd">USD</small>
                                                            </div>
                                                        </div>
                                                        <div class="nk-iv-wg3-subtitle">
                                                            Available Balance
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-7">
                                            <div class="nk-iv-wg3">
                                                <div class="nk-iv-wg3-title">
                                                    This Month
                                                    <em class="icon ni ni-info-fill" data-bs-toggle="tooltip"
                                                        data-bs-placement="right" title="Current Month Profit"></em>
                                                </div>
                                                <div class="nk-iv-wg3-group flex-md-nowrap g-4">
                                                    <div class="nk-iv-wg3-sub-group gx-4">
                                                        <div class="nk-iv-wg3-sub">
                                                            <div class="nk-iv-wg3-amount">
                                                                <div class="number">
                                                                    $<?php echo e(number_format($allUserInvestmentsThisMonth->sum('current_profit_amount'))); ?>

                                                                </div>
                                                            </div>
                                                            <div class="nk-iv-wg3-subtitle">
                                                                Total Profit
                                                            </div>
                                                        </div>
                                                        <div class="nk-iv-wg3-sub">
                                                            <span class="nk-iv-wg3-plus text-soft"><em
                                                                    class="icon ni ni-plus"></em></span>
                                                            <div class="nk-iv-wg3-amount">
                                                                <div class="number-sm">$<?php echo e(number_format($todayProfitSum)); ?>

                                                                </div>
                                                            </div>
                                                            <div class="nk-iv-wg3-subtitle">
                                                                Today Profit
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="nk-iv-wg3-sub flex-grow-1 ms-md-3">
                                                        <div class="nk-iv-wg3-ck">
                                                            <canvas class="chart-profit" id="profitCM"></canvas>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-inner">
                                    <ul class="nk-iv-wg3-nav">
                                        <li>
                                            <a href="#"><em class="icon ni ni-notes-alt"></em>
                                                <span>Go to Transaction</span></a>
                                        </li>
                                        <li>
                                            <a href="#"><em class="icon ni ni-growth"></em>
                                                <span>Analytic Reports</span></a>
                                        </li>
                                        <li>
                                            <a href="#"><em class="icon ni ni-report-profit"></em>
                                                <span>Monthly Statement</span></a>
                                        </li>
                                        <li>
                                            <a href="#"><em class="icon ni ni-help"></em>
                                                <span>Investment Tips</span></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="nk-block nk-block-lg">
                        <div class="nk-block-head-sm">
                            <div class="nk-block-head-content">
                                <h5 class="nk-block-title">
                                    Active Plan <span class="count text-base">(<?php echo e($allUserInvestments->count()); ?>)</span>
                                </h5>
                            </div>
                        </div>
                        <div class="nk-iv-scheme-list">
                            <?php if($allActiveUserInvestments): ?>
                                <?php $__currentLoopData = $allActiveUserInvestments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activeInvestment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="nk-iv-scheme-item">
                                        <div class="nk-iv-scheme-icon is-running">
                                            <em class="icon ni ni-update"></em>
                                        </div>
                                        <div class="nk-iv-scheme-info">
                                            <div class="nk-iv-scheme-name">
                                                <?php echo e($activeInvestment->product->name); ?> - Daily <?php echo e($activeInvestment->daily_profit_amount); ?>% for <?php echo e($activeInvestment->product->tenor); ?>

                                            </div>
                                            <div class="nk-iv-scheme-desc">
                                                Invested Amount - <span class="amount">$<?php echo e($activeInvestment->invested_amount); ?></span>
                                            </div>
                                        </div>
                                        <div class="nk-iv-scheme-term">
                                            <div class="nk-iv-scheme-start nk-iv-scheme-order">
                                                <span class="nk-iv-scheme-label text-soft">Start Date</span><span
                                                    class="nk-iv-scheme-value date"><?php echo e(\Carbon\Carbon::parse($activeInvestment->start_at)->format('M d, Y')); ?></span>
                                            </div>
                                            <div class="nk-iv-scheme-end nk-iv-scheme-order">
                                                <span class="nk-iv-scheme-label text-soft">End Date</span><span
                                                    class="nk-iv-scheme-value date"><?php echo e(\Carbon\Carbon::parse($activeInvestment->end_at)->format('M d, Y')); ?></span>
                                            </div>
                                        </div>
                                        <div class="nk-iv-scheme-amount">
                                            <div class="nk-iv-scheme-amount-a nk-iv-scheme-order">
                                                <?php
                                                // Get capital
                                                $capital = $activeInvestment->current_balance;

                                                // Get profit
                                                $profit = ($activeInvestment->daily_profit_amount/100) * $capital;

                                                ?>
                                                <span class="nk-iv-scheme-label text-soft">Total Return</span><span
                                                    class="nk-iv-scheme-value amount">$ <?php echo e($capital + $profit); ?></span>
                                            </div>
                                            <div class="nk-iv-scheme-amount-b nk-iv-scheme-order">
                                                <span class="nk-iv-scheme-label text-soft">Net Profit Earn</span><span
                                                    class="nk-iv-scheme-value amount">$ <?php echo e($profit); ?>

                                                    <span class="amount-ex">~ $<?php echo e($profit + 90); ?></span></span>
                                            </div>
                                        </div>
                                        <div class="nk-iv-scheme-more">
                                            <a class="btn btn-icon btn-lg btn-round btn-trans"
                                                href="scheme-details.html"><em class="icon ni ni-forward-ios"></em></a>
                                        </div>
                                        <div class="nk-iv-scheme-progress">
                                            <div class="progress-bar" data-progress="25"></div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <p>No Active Investments</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="nk-block nk-block-lg">
                        <div class="nk-block-head-sm">
                            <div class="nk-block-between">
                                <div class="nk-block-head-content">
                                    <h5 class="nk-block-title">
                                        Recently End <span class="count text-base">(<?php echo e($allEndedUserInvestments->count()); ?>)</span>
                                    </h5>
                                </div>
                                <div class="nk-block-head-content">
                                    <a href="#"><em class="icon ni ni-dot-box"></em> Go to Archive</a>
                                </div>
                            </div>
                        </div>
                        <div class="nk-iv-scheme-list">
                            <?php if($allEndedUserInvestments): ?>
                                <?php $__currentLoopData = $allEndedUserInvestments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inactiveInvestment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="nk-iv-scheme-item">
                                        <div class="nk-iv-scheme-icon is-running">
                                            <em class="icon ni ni-update"></em>
                                        </div>
                                        <div class="nk-iv-scheme-info">
                                            <div class="nk-iv-scheme-name">
                                                <?php echo e($inactiveInvestment->product->name); ?> - Daily <?php echo e($inactiveInvestment->daily_profit_amount); ?>% for <?php echo e($inactiveInvestment->product->tenor); ?>

                                            </div>
                                            <div class="nk-iv-scheme-desc">
                                                Invested Amount - <span class="amount">$<?php echo e($inactiveInvestment->invested_amount); ?></span>
                                            </div>
                                        </div>
                                        <div class="nk-iv-scheme-term">
                                            <div class="nk-iv-scheme-start nk-iv-scheme-order">
                                                <span class="nk-iv-scheme-label text-soft">Start Date</span><span
                                                    class="nk-iv-scheme-value date"><?php echo e(\Carbon\Carbon::parse($inactiveInvestment->start_at)->format('M d, Y')); ?></span>
                                            </div>
                                            <div class="nk-iv-scheme-end nk-iv-scheme-order">
                                                <span class="nk-iv-scheme-label text-soft">End Date</span><span
                                                    class="nk-iv-scheme-value date"><?php echo e(\Carbon\Carbon::parse($inactiveInvestment->end_at)->format('M d, Y')); ?></span>
                                            </div>
                                        </div>
                                        <div class="nk-iv-scheme-amount">
                                            <div class="nk-iv-scheme-amount-a nk-iv-scheme-order">
                                                <?php
                                                // Get capital
                                                $capital = $inactiveInvestment->current_balance;

                                                // Get profit
                                                $profit = ($inactiveInvestment->daily_profit_amount/100) * $capital;

                                                ?>
                                                <span class="nk-iv-scheme-label text-soft">Total Return</span><span
                                                    class="nk-iv-scheme-value amount">$ <?php echo e($capital + $profit); ?></span>
                                            </div>
                                            <div class="nk-iv-scheme-amount-b nk-iv-scheme-order">
                                                <span class="nk-iv-scheme-label text-soft">Net Profit Earn</span><span
                                                    class="nk-iv-scheme-value amount">$ <?php echo e($profit); ?>

                                                    <span class="amount-ex">~ $<?php echo e($profit + 90); ?></span></span>
                                            </div>
                                        </div>
                                        <div class="nk-iv-scheme-more">
                                            <a class="btn btn-icon btn-lg btn-round btn-trans"
                                                href="scheme-details.html"><em class="icon ni ni-forward-ios"></em></a>
                                        </div>
                                        <div class="nk-iv-scheme-progress">
                                            <div class="progress-bar" data-progress="25"></div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="alert alert-info">
                                    <p>No Inactive Investments</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\dinerius\dinerius-investment-app\resources\views/dashboard/user-investments.blade.php ENDPATH**/ ?>