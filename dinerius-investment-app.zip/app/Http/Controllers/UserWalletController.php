<?php

namespace App\Http\Controllers;

use App\Models\UserWallet;
use App\Http\Requests\StoreUserWalletRequest;
use App\Http\Requests\UpdateUserWalletRequest;

class UserWalletController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreUserWalletRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(UserWallet $userWallet)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(UserWallet $userWallet)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUserWalletRequest $request, UserWallet $userWallet)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(UserWallet $userWallet)
    {
        //
    }
}
