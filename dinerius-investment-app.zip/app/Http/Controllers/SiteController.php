<?php

namespace App\Http\Controllers;

class SiteController extends Controller
{
    public function home()
    {
        return view('site.home');
    }

    public function about()
    {
        return view('site.about');
    }

    public function products()
    {
        return view('site.products');
    }

    public function contact()
    {
        return view('site.contact');
    }

    public function signin()
    {
        return view('site.signin');
    }

    public function guide()
    {
        return view('site.guide');
    }

    public function education(){
        return view('site.education');
    }
}
