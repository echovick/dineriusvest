<?php

namespace App\Http\Controllers;

use App\Models\UserPin;
use App\Http\Requests\StoreUserPinRequest;
use App\Http\Requests\UpdateUserPinRequest;

class UserPinController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreUserPinRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(UserPin $userPin)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(UserPin $userPin)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateUserPinRequest $request, UserPin $userPin)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(UserPin $userPin)
    {
        //
    }
}
